def convert_c_to_f(temp_in_c)
	puts temp_in_c * (9.0 / 5) + 32
end

convert_c_to_f(27)
