def convert_f_to_c(temp_in_f)
	puts (temp_in_f - 32) * (5.0 / 9)
end

convert_f_to_c(81)
